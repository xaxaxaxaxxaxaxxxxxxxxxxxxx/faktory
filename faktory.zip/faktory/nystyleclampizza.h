#ifndef NYSTYLECLAMPIZZA_H
#define NYSTYLECLAMPIZZA_H
#include "pizza.h"

class NYStyleClamPizza :public Pizza
{
	public:
		NYStyleClamPizza();
		void cut();
};

#endif // NYSTYLECLAMPIZZA_H
