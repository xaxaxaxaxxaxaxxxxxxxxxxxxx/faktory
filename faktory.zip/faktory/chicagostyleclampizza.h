#ifndef CHICAGOSTYLECLAMPIZZA_H
#define CHICAGOSTYLECLAMPIZZA_H
#include "pizza.h"

class ChicagoStyleClamPizza: public Pizza
{
	public:
		ChicagoStyleClamPizza();
		void cut();
};

#endif // CHICAGOSTYLECLAMPIZZA_H

