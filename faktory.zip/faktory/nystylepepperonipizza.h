#ifndef NYSTYLEPEPPERONIPIZZA_H
#define NYSTYLEPEPPERONIPIZZA_H
#include "pizza.h"

class NYStylePepperoniPizza: public Pizza
{
	public:
		NYStylePepperoniPizza();
		void cut();

};

#endif // NYSTYLEPEPPERONIPIZZA_H


