#ifndef NYSTYLECHEEZEPIZZA_H
#define NYSTYLECHEEZEPIZZA_H

#include "pizza.h"

class NYStyleCheezePizza : public Pizza
{
public:
    NYStyleCheezePizza();
    void cut();
};

#endif // NYSTYLECHEEZEPIZZA_H
