#ifndef CHICAGOSTYLECHEESEPIZZA_H
#define CHICAGOSTYLECHEESEPIZZA_H
#include "pizza.h"

class ChicagoStyleCheesePizza : public Pizza {
	public:
		ChicagoStyleCheesePizza();
		void cut();
	
};

#endif // CHICAGOSTYLECHEESEPIZZA_H
