#ifndef CHICAGOSTYLEPEPPERONIPIZZA_H
#define CHICAGOSTYLEPEPPERONIPIZZA_H
#include "pizza.h"

class ChicagoStylePepperoniPizza : public Pizza
{
	public:
		ChicagoStylePepperoniPizza();
		void cut();
};

#endif // CHICAGOSTYLEPEPPERONIPIZZA_H
