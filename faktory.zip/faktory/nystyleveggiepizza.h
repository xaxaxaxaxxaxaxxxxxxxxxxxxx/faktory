#ifndef NYSTYLEVEGGIEPIZZA_H
#define NYSTYLEVEGGIEPIZZA_H
#include "pizza.h"

class NYStyleVeggiePizza : public Pizza
{
	public:
		NYStyleVeggiePizza();
		void cut();
};

#endif // NYSTYLEVEGGIEPIZZA_H

